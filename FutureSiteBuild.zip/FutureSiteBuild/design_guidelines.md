# Design Guidelines: SDG Club Website - Strathmore University

## Design Approach
**System Selected**: Custom Futuristic Design with Material Design influences for micro-interactions
**Rationale**: The project requires a unique, energy-driven aesthetic that standard design systems cannot provide. We'll create a custom system centered on neon accents, dark themes, and futuristic elements while borrowing interaction patterns from Material Design.

---

## Core Design Elements

### A. Color System
**Foundation Colors:**
- Dark Navy `#0D1B2A` - Primary background
- Midnight Blue `#1B263B` - Section backgrounds and cards
- White `#FFFFFF` - Primary text
- Light Gray `#C0C0C0` - Secondary text

**Accent Colors:**
- Electric Blue `#00BFFF` - Primary CTAs, highlights, glow effects
- Neon Purple `#9B59B6` - Gradients, hover states, secondary accents
- Bright Cyan `#00FFFF` - Micro-interactions, borders, subtle accents

**Color Application:**
- All buttons use Electric Blue with neon glow effects
- Gradient overlays combine Neon Purple → Electric Blue
- Text glows use Electric Blue at 50% opacity
- Card borders use Bright Cyan with subtle pulse animation

### B. Typography
**Font Stack:**
- Primary: Inter or Poppins (Google Fonts) - Clean, modern, tech-forward
- Headings: 700 weight with subtle letter-spacing (0.02em)
- Body: 400 weight, 1.6 line-height for readability

**Hierarchy:**
- Hero Title: 4rem (desktop), 2.5rem (mobile) - White with Electric Blue text-shadow glow
- Section Headers: 2.5rem (desktop), 1.75rem (mobile) - White
- Card Titles: 1.5rem - White
- Body Text: 1rem - Light Gray
- Micro-copy: 0.875rem - Light Gray at 80% opacity

### C. Layout & Spacing
**Grid System:**
- Max-width container: 1280px
- Section padding: py-20 (desktop), py-12 (mobile)
- Card spacing: gap-8 (desktop), gap-6 (mobile)
- Common spacing units: 4, 8, 12, 16, 20 (Tailwind units)

**Layout Patterns:**
- Hero: Full viewport height (100vh) with centered content
- About Section: Single column with max-width 800px for readability
- SDGs Grid: 3 columns (desktop), 2 columns (tablet), 1 column (mobile)
- Footer: 4-column layout (desktop), stacked (mobile)

---

## Component Library

### Navigation Bar
- Sticky/fixed position with semi-transparent Midnight Blue background (85% opacity)
- Backdrop blur effect (blur-md)
- Items: Home, About, SDGs, Register
- Electric Blue underline on hover (3px height, smooth transition)
- Neon glow on active state
- Logo: Strathmore SDG Club with subtle Electric Blue accent

### Hero Section
**Structure:**
- Full-width, 100vh height
- Split layout: Left (60%) - Text content, Right (40%) - Spline 3D Globe
- Background: Dark Navy with animated gradient particles or waves
- Text overlay: Semi-transparent backdrop for readability

**Content:**
- Main heading: "Strathmore Youth & the Sustainable Development Goals (SDGs)"
- Electric Blue glow effect on heading (0 0 20px rgba(0, 191, 255, 0.6))
- Subheading: Brief mission statement (Light Gray, 1.25rem)
- Primary CTA: "Register Now" button (Electric Blue, neon glow, scale on hover)
- Background animation: Subtle moving particles or gradient waves

**Globe Integration:**
- Spline Community 3D revolving globe (react-spline library)
- Auto-rotating, interactive on hover
- Ambient glow around globe using radial gradient

### About SDG Club Section
**Layout:**
- Full-width section, Midnight Blue background
- Content in centered container (max-width 900px)
- Multi-card breakdown of content from Strathmore article

**Card Design:**
- Glass-morphism style: semi-transparent Midnight Blue with backdrop blur
- Border: 1px Bright Cyan with subtle glow
- Padding: p-8
- Hover: Lift effect (translate-y -8px, shadow increase)
- Icons: Heroicons or Font Awesome in Electric Blue

**Content Blocks:**
1. "Why Youth Own SDGs" - Inclusivity, Future, Policy cards
2. "Youth Role in SDGs" - Advocacy, Localization, Innovation, Action
3. "How to Participate" - Learn, Network, Action-Oriented, Resilience
4. "About Strathmore SDG Hub" - SDSN Youth global network info

**Animations:**
- Fade-in from bottom on scroll (translate-y 30px → 0)
- Stagger delay between cards (100ms increments)

### SDG Showcase Section
**Grid Layout:**
- Title: "The 17 Sustainable Development Goals"
- 3-column grid (desktop), 2-column (tablet), 1-column (mobile)
- Gap: 8 units between cards

**SDG Card Design:**
- Size: Square aspect ratio (1:1) or 4:3
- Background: Official SDG color for each goal
- Border: 2px Bright Cyan with animated neon glow pulse
- Content: SDG icon/number, title, brief description
- Overlay: Gradient (transparent → Neon Purple 20%) on hover

**Hover Effects:**
- Scale: 1.05 transform
- Shadow: Dramatic increase with colored glow matching SDG color
- Rotate: Subtle 2-degree tilt
- Glow pulse: Cyan border intensity increases
- Transition: 300ms smooth

**SDG Official Colors** (use exact colors for each):
- Goal 1 (No Poverty): #E5243B
- Goal 2 (Zero Hunger): #DDA63A
- Goal 3 (Good Health): #4C9F38
- Goal 4 (Quality Education): #C5192D
- Goal 5 (Gender Equality): #FF3A21
- Goal 6 (Clean Water): #26BDE2
- Goal 7 (Affordable Energy): #FCC30B
- Goal 8 (Decent Work): #A21942
- Goal 9 (Industry Innovation): #FD6925
- Goal 10 (Reduced Inequalities): #DD1367
- Goal 11 (Sustainable Cities): #FD9D24
- Goal 12 (Responsible Consumption): #BF8B2E
- Goal 13 (Climate Action): #3F7E44
- Goal 14 (Life Below Water): #0A97D9
- Goal 15 (Life on Land): #56C02B
- Goal 16 (Peace & Justice): #00689D
- Goal 17 (Partnerships): #19486A

### Registration Section
**Placement:** Dedicated section + Hero CTA
**Design:**
- Centered layout with compelling copy
- Large "Register Now" button (Electric Blue, pulsing glow)
- Supporting text: "Join 100+ students making a difference"
- Background: Gradient overlay (Dark Navy → Midnight Blue)
- Decorative elements: Floating geometric shapes with neon outlines

**Button Specifications:**
- Padding: px-12 py-4
- Border radius: 0.5rem
- Box shadow: 0 0 30px rgba(0, 191, 255, 0.5)
- Hover: Increase glow, scale 1.05
- Click: Brief scale-down (0.95) then external link

### Footer
**Layout:** 4-column grid (desktop), stacked (mobile)
**Columns:**
1. Branding: SDG Club logo + tagline
2. Quick Links: Home, About, SDGs
3. Contact: Email (sbscommunication@strathmore.edu)
4. Social: Icons with hover glow

**Styling:**
- Background: Midnight Blue with top border (1px Bright Cyan)
- Text: Light Gray
- Social icons: Circle containers with Cyan border, Electric Blue fill on hover
- Icon glow: Subtle cyan halo on hover
- Copyright: Centered, smaller text

---

## Animations & Effects

### Scroll-Triggered Animations
- Fade-in: opacity 0 → 1, translate-y 30px → 0
- Slide-up: translate-y 50px → 0 over 600ms
- Stagger: 100ms delay between sequential elements
- Trigger: When element enters viewport (80% visibility)

### Micro-Interactions
- Button hover: Scale 1.05, glow intensity increase
- Card hover: Lift (translate-y -8px), shadow expansion
- Link hover: Electric Blue underline slide-in (left to right)
- Icon hover: Rotate 360° or pulse scale

### Background Animations
- Hero: Slow-moving gradient waves or particle system
- Sections: Subtle parallax scroll (20% speed difference)
- Globe: Auto-rotation with interactive pause on hover

### Transitions
- Default duration: 300ms
- Timing function: cubic-bezier(0.4, 0, 0.2, 1)
- Never exceed 600ms for UX

---

## Images & Assets

**Hero Section:**
- Spline 3D Globe (embed): Interactive revolving Earth from Spline Community
- Background: Abstract tech pattern or gradient animation (CSS/SVG)

**SDG Cards:**
- Official SDG icons (download from UN SDG website)
- High-resolution, optimized PNG/SVG format

**About Section:**
- Optional: Photo of Strathmore SDG Hub team or event
- Decorative: Abstract geometric shapes with neon outlines

**Icons:**
- Heroicons (via CDN) for UI elements
- Use outline style for navigation, solid for emphasis

---

## Responsive Behavior

**Breakpoints:**
- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

**Key Adaptations:**
- Hero: Stack globe below text on mobile
- SDG Grid: 3 cols → 2 cols → 1 col
- Navigation: Hamburger menu on mobile
- Typography: Scale down by 30-40% on mobile
- Spacing: Reduce padding by 40% on mobile
- Globe: Reduce height to 400px on mobile

---

## Performance & Accessibility

**Optimization:**
- Lazy load Spline globe component
- Optimize all images (WebP format)
- Minimize animation on reduced-motion preference
- Fast loading: Critical CSS inline, defer non-critical

**Accessibility:**
- ARIA labels on all interactive elements
- Keyboard navigation support
- Focus states: Cyan outline (2px, offset 2px)
- Color contrast: All text meets WCAG AA (4.5:1 minimum)
- Alt text on all images describing SDG content

---

## Key Differentiators
This design stands apart through:
- **Immersive 3D Integration**: Spline globe creates memorable first impression
- **Neon Futurism**: Bold color palette with glows/gradients evokes innovation
- **Purpose-Driven**: Every element reinforces SDG mission and youth empowerment
- **Interactive Excellence**: Smooth animations reward exploration without overwhelming