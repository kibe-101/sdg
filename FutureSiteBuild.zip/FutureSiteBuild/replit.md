# SDG Club - Strathmore University

## Overview

This is a static website for the Sustainable Development Goals (SDG) Club at Strathmore University. The application serves as a digital hub for youth engagement with the UN's 17 Sustainable Development Goals, featuring a modern futuristic design aesthetic with neon accents and dark themes. The site provides information about the SDG Club, displays all 17 SDGs with official colors, and facilitates member registration through an external Google Form.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript, built using Vite as the build tool and development server.

**Routing**: Wouter is used for client-side routing, providing a lightweight alternative to React Router. The application currently has a simple route structure with a home page and a 404 not-found page.

**UI Component System**: The application uses shadcn/ui (New York style variant) as its component library, built on top of Radix UI primitives. This provides accessible, customizable components with:
- Tailwind CSS for styling with custom CSS variables for theming
- Custom color system featuring dark navy backgrounds, electric blue accents, neon purple gradients, and bright cyan highlights
- Component path aliases configured for clean imports (`@/components`, `@/lib`, `@/hooks`)

**State Management**: React Query (TanStack Query v5) handles server state management and data fetching, though currently the application is primarily static with minimal server interactions.

**Design System**: Custom futuristic design with Material Design influences for micro-interactions. Key characteristics:
- Dark theme with neon glow effects
- Gradient animations and transitions
- Scroll-based animations using react-intersection-observer
- Custom spacing and typography scales
- Responsive design for desktop, tablet, and mobile viewports

**Component Structure**:
- Page-level components in `client/src/pages/`
- Reusable section components (HeroSection, AboutSection, SDGsSection, RegistrationSection, Footer, Navigation)
- UI primitives in `client/src/components/ui/`
- Shared utilities and hooks in `client/src/lib/` and `client/src/hooks/`

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript.

**Build Strategy**: 
- Client-side: Vite bundles the React application into static assets
- Server-side: esbuild bundles the Express server into a single output file
- Development: Vite dev server with HMR (Hot Module Replacement) integrated with Express
- Production: Pre-built static files served by Express

**Storage Layer**: Currently implements an in-memory storage pattern with a `MemStorage` class that implements the `IStorage` interface. This is designed to be swappable with a database implementation. The storage interface includes basic CRUD operations for users (getUser, getUserByUsername, createUser).

**API Structure**: Minimal API surface - routes are registered in `server/routes.ts` but currently the application is primarily static. The route registration pattern is in place for future expansion.

**Middleware Stack**:
- JSON body parsing with raw body capture for webhook support
- URL-encoded form parsing
- Request logging with duration tracking for API routes
- Development-specific Replit plugins (cartographer, dev banner, runtime error overlay)

### Data Storage Solutions

**Database Configuration**: Drizzle ORM configured for PostgreSQL using the Neon serverless driver. While configured, the application currently uses in-memory storage for simplicity.

**Schema Definition** (in `shared/schema.ts`):
- Users table with UUID primary key, username, and password fields
- Zod validation schemas derived from Drizzle schema definitions
- Schema migration files generated in the `migrations/` directory

**Database Design Philosophy**: The schema is minimal, suggesting this is primarily a content-focused application rather than data-intensive. The user schema appears to be boilerplate that may not be actively used given the static nature of the site and external Google Form registration.

### External Dependencies

**Third-Party Services**:
- **Google Forms**: Registration handling via embedded form link (https://forms.gle/W9T8vXnmDgxdMT3o9)
- **Spline Community**: 3D revolving globe visualization in hero section using @splinetool/react-spline
- **Google Fonts**: Inter and Poppins font families loaded from Google Fonts CDN

**Database & Infrastructure**:
- **Neon Database**: Serverless PostgreSQL configured via DATABASE_URL environment variable
- **Drizzle ORM**: Type-safe database operations with migration support

**UI Component Libraries**:
- **Radix UI**: Comprehensive collection of accessible React components (accordion, dialog, dropdown-menu, popover, select, tabs, toast, etc.)
- **shadcn/ui**: Opinionated component layer built on Radix UI
- **Lucide React**: Icon library for consistent iconography
- **React Icons**: Additional icon support (used for social media icons)

**Animation & Interaction**:
- **react-intersection-observer**: Scroll-based animation triggers
- **class-variance-authority**: Type-safe variant styling
- **tailwind-merge**: Intelligent Tailwind class merging
- **clsx**: Conditional className composition

**Development Tools**:
- **Replit Plugins**: Custom Vite plugins for development environment enhancement
- **TypeScript**: Full type safety across client and server
- **ESBuild**: Fast server-side bundling for production