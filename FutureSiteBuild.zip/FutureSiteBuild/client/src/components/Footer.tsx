import { Button } from '@/components/ui/button';
import { Mail, ExternalLink } from 'lucide-react';
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from 'react-icons/fa';

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const quickLinks = [
    { label: 'Home', id: 'hero' },
    { label: 'About', id: 'about' },
    { label: 'SDGs', id: 'sdgs' },
    { label: 'Register', id: 'register' },
  ];

  const socialLinks = [
    { icon: FaFacebook, label: 'Facebook', href: '#' },
    { icon: FaTwitter, label: 'Twitter', href: '#' },
    { icon: FaInstagram, label: 'Instagram', href: '#' },
    { icon: FaLinkedin, label: 'LinkedIn', href: '#' },
  ];

  return (
    <footer className="relative bg-card border-t border-accent/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <h3 className="text-2xl font-bold mb-4" data-testid="footer-branding">
              <span className="text-primary neon-glow">SDG</span> Club
            </h3>
            <p className="text-muted-foreground mb-4">
              Strathmore University's hub for sustainable development and youth empowerment.
            </p>
            <p className="text-sm text-muted-foreground">
              Part of SDSN Youth - A global network of 100+ university hubs.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.id}>
                  <Button
                    variant="ghost"
                    onClick={() => scrollToSection(link.id)}
                    className="h-auto p-0 text-muted-foreground hover:text-primary transition-colors"
                    data-testid={`footer-link-${link.id}`}
                  >
                    {link.label}
                  </Button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Contact</h4>
            <div className="space-y-3">
              <a
                href="mailto:sbscommunication@strathmore.edu"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors group"
                data-testid="footer-email"
              >
                <Mail className="w-4 h-4 group-hover:scale-110 transition-transform" />
                <span className="text-sm">sbscommunication@strathmore.edu</span>
              </a>
              <a
                href="https://sbs.strathmore.edu/youth-and-the-sustainable-development-goals-sdgs/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors group"
                data-testid="footer-website"
              >
                <ExternalLink className="w-4 h-4 group-hover:scale-110 transition-transform" />
                <span className="text-sm">Official Article</span>
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Follow Us</h4>
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full border border-accent/30 flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary hover:scale-110 transition-all neon-glow-cyan"
                  aria-label={social.label}
                  data-testid={`footer-social-${social.label.toLowerCase()}`}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-accent/20">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground text-center sm:text-left" data-testid="footer-copyright">
              © {new Date().getFullYear()} Strathmore University SDG Club. All rights reserved.
            </p>
            <p className="text-sm text-muted-foreground text-center sm:text-right">
              Powered by <span className="text-primary">youth action</span> for a sustainable future
            </p>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-secondary to-accent" />
    </footer>
  );
}
