import { useInView } from 'react-intersection-observer';
import { Card } from '@/components/ui/card';
import { Users, Target, Lightbulb, Rocket, Network, BookOpen, TrendingUp, Zap } from 'lucide-react';

export default function AboutSection() {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const reasons = [
    {
      icon: Users,
      title: 'Inclusivity',
      description: 'At the core of the SDGs is leaving no one behind. The SDGs cannot be achieved without the youth.',
    },
    {
      icon: Target,
      title: 'The Future Belongs to Youth',
      description: 'Solutions come from including those affected. The future we fight for is our future as the youth.',
    },
    {
      icon: Lightbulb,
      title: 'Shaping Policies',
      description: 'Youth play a huge role in shaping policies and providing ideas that work in their communities.',
    },
  ];

  const roles = [
    {
      icon: Rocket,
      title: 'Advocacy Work',
      description: 'Actively appearing in campaigns, raising awareness through walks, trivia games, summits and seminars.',
    },
    {
      icon: Network,
      title: 'Localization of SDGs',
      description: 'Teaching communities about the SDGs and what they mean, reflecting the "Leave no one behind" policy.',
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'At the forefront with technology, innovating ideas to address climate change, mobility and inclusivity.',
    },
    {
      icon: Zap,
      title: 'Action',
      description: 'Involved in tree planting, clean-ups, working with schools, friendly farming and community projects.',
    },
  ];

  const steps = [
    {
      icon: BookOpen,
      title: 'Learn and Research',
      description: 'Be aware of what\'s happening in your community. Research SDGs, know key stakeholders and organizations.',
    },
    {
      icon: Network,
      title: 'Network with the Right People',
      description: 'Find relevant mentors and connect with advocates in your context who share your passion.',
    },
    {
      icon: Rocket,
      title: 'Be Action-Oriented',
      description: 'Making noise isn\'t enough. The end goal is action. Push for real change in your community.',
    },
    {
      icon: TrendingUp,
      title: 'Be Consistent and Resilient',
      description: 'Fight for your space, constantly learn, and evolve. Resilience tied with consistency creates impact.',
    },
  ];

  return (
    <section id="about" className="relative py-20 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/50 to-background" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        <div className={`text-center mb-16 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            About the <span className="text-primary neon-glow">SDG Club</span>
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto">
            "The future of humanity and of our planet lies in our hands. It also lies in the hands of today's younger generation who will pass the torch to future generations."
          </p>
          <p className="text-sm text-muted-foreground mt-2 italic">- Youth and the 2030 Agenda for Sustainable Development</p>
        </div>

        <div className="mb-20">
          <h3 className={`text-2xl sm:text-3xl font-bold text-center mb-12 transition-all duration-1000 delay-200 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            Why Youth <span className="text-primary">Own the SDGs</span>
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            {reasons.map((reason, index) => (
              <Card
                key={index}
                className={`p-6 border-accent/20 hover:border-accent/40 backdrop-blur-glass transition-all duration-500 hover:-translate-y-2 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${(index + 3) * 100}ms` }}
                data-testid={`card-reason-${index}`}
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <reason.icon className="w-6 h-6 text-primary" />
                </div>
                <h4 className="text-xl font-semibold mb-3">{reason.title}</h4>
                <p className="text-muted-foreground">{reason.description}</p>
              </Card>
            ))}
          </div>
        </div>

        <div className="mb-20">
          <h3 className={`text-2xl sm:text-3xl font-bold text-center mb-12 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <span className="text-primary">Youth Role</span> in Promoting SDGs
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {roles.map((role, index) => (
              <Card
                key={index}
                className={`p-6 border-accent/20 hover:border-accent/40 backdrop-blur-glass transition-all duration-500 hover:-translate-y-2 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${(index + 6) * 100}ms` }}
                data-testid={`card-role-${index}`}
              >
                <div className="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center mb-3">
                  <role.icon className="w-5 h-5 text-secondary" />
                </div>
                <h4 className="text-lg font-semibold mb-2">{role.title}</h4>
                <p className="text-sm text-muted-foreground">{role.description}</p>
              </Card>
            ))}
          </div>
        </div>

        <div className="mb-20">
          <h3 className={`text-2xl sm:text-3xl font-bold text-center mb-12 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            How to <span className="text-primary">Actively Participate</span>
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, index) => (
              <Card
                key={index}
                className={`p-6 border-accent/20 hover:border-accent/40 backdrop-blur-glass transition-all duration-500 hover:-translate-y-2 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
                style={{ transitionDelay: `${(index + 10) * 100}ms` }}
                data-testid={`card-step-${index}`}
              >
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center mb-3">
                  <step.icon className="w-5 h-5 text-accent" />
                </div>
                <h4 className="text-lg font-semibold mb-2">{step.title}</h4>
                <p className="text-sm text-muted-foreground">{step.description}</p>
              </Card>
            ))}
          </div>
        </div>

        <Card className={`p-8 sm:p-12 backdrop-blur-glass border-primary/30 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{ transitionDelay: '1400ms' }} data-testid="card-sdg-hub">
          <h3 className="text-2xl sm:text-3xl font-bold mb-6 text-center">
            About the <span className="text-primary">Strathmore SDG Hub</span>
          </h3>
          <div className="space-y-4 text-muted-foreground max-w-4xl mx-auto">
            <p>
              The SDG Student's Hub is part of <strong className="text-foreground">SDSN Youth</strong>, a program of the UN Sustainable Development Solutions Network launched by UN Secretary-General Ban Ki-moon in 2012.
            </p>
            <p>
              This initiative accelerates youth action and mobilizes expertise around the SDGs globally. With over <strong className="text-primary">100 Hubs worldwide</strong>, the Strathmore SDG Hub is one of the few in Kenya.
            </p>
            <p className="text-lg font-medium text-foreground italic text-center pt-4">
              "If you tap into the potential of young people - into their creativity, idealism and numbers - you are going to start the biggest movement for sustainable development in history."
            </p>
            <p className="text-center text-sm">- Sam Loni, Founder of SDSN Youth</p>
          </div>
        </Card>
      </div>
    </section>
  );
}
