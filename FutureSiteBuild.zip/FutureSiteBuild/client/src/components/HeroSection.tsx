import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles, Globe2 } from 'lucide-react';

export default function HeroSection() {
  const handleRegisterClick = () => {
    window.open('https://forms.gle/W9T8vXnmDgxdMT3o9', '_blank');
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-background via-card to-background" />
      
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-accent/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '4s' }} />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm text-primary font-medium">SDSN Youth Initiative</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
              <span className="text-foreground">Strathmore Youth & the </span>
              <span className="text-primary neon-glow">Sustainable Development Goals</span>
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed">
              Join the global movement of youth creating sustainable change. Engage, Act, and Interact with the 17 SDGs to build a better future for all.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                onClick={handleRegisterClick}
                className="neon-glow-primary hover:scale-105 transition-transform text-base sm:text-lg"
                data-testid="button-hero-register"
              >
                Register Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                className="border-accent/30 hover:border-accent text-base sm:text-lg"
                data-testid="button-hero-learn-more"
              >
                Learn More
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div>
                <div className="text-3xl font-bold text-primary">100+</div>
                <div className="text-sm text-muted-foreground">Active Members</div>
              </div>
              <div className="w-px h-12 bg-border" />
              <div>
                <div className="text-3xl font-bold text-primary">17</div>
                <div className="text-sm text-muted-foreground">Global Goals</div>
              </div>
              <div className="w-px h-12 bg-border" />
              <div>
                <div className="text-3xl font-bold text-primary">Global</div>
                <div className="text-sm text-muted-foreground">Impact</div>
              </div>
            </div>
          </div>

          <div className="relative h-[400px] sm:h-[500px] lg:h-[600px] flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-full blur-3xl" />
            
            <div className="relative w-full h-full flex items-center justify-center">
              <div className="relative w-80 h-80 sm:w-96 sm:h-96">
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/30 via-accent/30 to-secondary/30 animate-gradient blur-xl" />
                
                <div className="absolute inset-8 rounded-full bg-gradient-to-br from-primary/40 to-secondary/40 neon-glow-cyan animate-pulse-glow" />
                
                <div className="absolute inset-0 flex items-center justify-center">
                  <Globe2 className="w-48 h-48 sm:w-56 sm:h-56 text-primary animate-float" strokeWidth={0.5} />
                </div>
                
                <div className="absolute inset-0 rounded-full border-2 border-accent/30 animate-spin" style={{ animationDuration: '20s' }} />
                <div className="absolute inset-4 rounded-full border border-primary/20 animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }} />
                <div className="absolute inset-8 rounded-full border border-secondary/20 animate-spin" style={{ animationDuration: '25s' }} />
                
                <div className="absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-accent/50 to-transparent" />
                <div className="absolute top-0 left-1/2 w-px h-full bg-gradient-to-b from-transparent via-accent/50 to-transparent" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-primary/50 rounded-full p-1">
          <div className="w-1.5 h-3 bg-primary rounded-full mx-auto animate-pulse" />
        </div>
      </div>
    </section>
  );
}
