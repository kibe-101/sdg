import RegistrationSection from '../RegistrationSection';

export default function RegistrationSectionExample() {
  return <RegistrationSection />;
}
