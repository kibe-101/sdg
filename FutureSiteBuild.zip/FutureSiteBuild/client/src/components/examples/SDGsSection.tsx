import SDGsSection from '../SDGsSection';

export default function SDGsSectionExample() {
  return <SDGsSection />;
}
