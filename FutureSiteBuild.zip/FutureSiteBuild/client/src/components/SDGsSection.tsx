import { useInView } from 'react-intersection-observer';
import { Card } from '@/components/ui/card';

export default function SDGsSection() {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.05,
  });

  const sdgs = [
    { number: 1, title: 'No Poverty', color: '#E5243B', description: 'End poverty in all its forms everywhere' },
    { number: 2, title: 'Zero Hunger', color: '#DDA63A', description: 'End hunger, achieve food security and improved nutrition' },
    { number: 3, title: 'Good Health', color: '#4C9F38', description: 'Ensure healthy lives and promote well-being for all' },
    { number: 4, title: 'Quality Education', color: '#C5192D', description: 'Ensure inclusive and equitable quality education' },
    { number: 5, title: 'Gender Equality', color: '#FF3A21', description: 'Achieve gender equality and empower all women and girls' },
    { number: 6, title: 'Clean Water', color: '#26BDE2', description: 'Ensure availability and sustainable management of water' },
    { number: 7, title: 'Affordable Energy', color: '#FCC30B', description: 'Ensure access to affordable, reliable, sustainable energy' },
    { number: 8, title: 'Decent Work', color: '#A21942', description: 'Promote sustained, inclusive economic growth and employment' },
    { number: 9, title: 'Industry Innovation', color: '#FD6925', description: 'Build resilient infrastructure, promote inclusive industrialization' },
    { number: 10, title: 'Reduced Inequalities', color: '#DD1367', description: 'Reduce inequality within and among countries' },
    { number: 11, title: 'Sustainable Cities', color: '#FD9D24', description: 'Make cities and human settlements inclusive and sustainable' },
    { number: 12, title: 'Responsible Consumption', color: '#BF8B2E', description: 'Ensure sustainable consumption and production patterns' },
    { number: 13, title: 'Climate Action', color: '#3F7E44', description: 'Take urgent action to combat climate change' },
    { number: 14, title: 'Life Below Water', color: '#0A97D9', description: 'Conserve and sustainably use the oceans, seas and marine resources' },
    { number: 15, title: 'Life on Land', color: '#56C02B', description: 'Protect, restore and promote sustainable use of terrestrial ecosystems' },
    { number: 16, title: 'Peace & Justice', color: '#00689D', description: 'Promote peaceful and inclusive societies for sustainable development' },
    { number: 17, title: 'Partnerships', color: '#19486A', description: 'Strengthen the means of implementation and revitalize partnerships' },
  ];

  return (
    <section id="sdgs" className="relative py-20 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/30 to-background" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        <div className={`text-center mb-16 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
            The 17 <span className="text-primary neon-glow">Sustainable Development Goals</span>
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto">
            A global vision to shape a more sustainable future. Engage with each goal to create lasting impact.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {sdgs.map((sdg, index) => (
            <Card
              key={sdg.number}
              className={`group relative overflow-hidden border-2 transition-all duration-500 hover:scale-105 hover:rotate-1 hover:shadow-2xl cursor-pointer animate-pulse-glow ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
              style={{
                borderColor: sdg.color,
                transitionDelay: `${index * 50}ms`,
                backgroundColor: sdg.color,
              }}
              data-testid={`card-sdg-${sdg.number}`}
            >
              <div
                className="absolute inset-0 opacity-90 group-hover:opacity-100 transition-opacity"
                style={{ backgroundColor: sdg.color }}
              />
              
              <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-secondary/40 opacity-0 group-hover:opacity-100 transition-opacity" />
              
              <div className="relative p-6 text-white">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-5xl sm:text-6xl font-bold opacity-30">
                    {sdg.number}
                  </div>
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
                    <span className="text-lg font-bold">{sdg.number}</span>
                  </div>
                </div>
                
                <h3 className="text-xl sm:text-2xl font-bold mb-3 drop-shadow-lg">
                  {sdg.title}
                </h3>
                
                <p className="text-sm opacity-90 drop-shadow-md">
                  {sdg.description}
                </p>

                <div className="absolute top-0 left-0 w-1 h-0 bg-white group-hover:h-full transition-all duration-500" />
                <div className="absolute bottom-0 right-0 w-0 h-1 bg-white group-hover:w-full transition-all duration-500" />
              </div>
            </Card>
          ))}
        </div>

        <div className={`mt-16 text-center transition-all duration-1000 delay-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Each goal represents a critical area where youth can make a difference. Together, we can achieve sustainable development by 2030.
          </p>
        </div>
      </div>
    </section>
  );
}
