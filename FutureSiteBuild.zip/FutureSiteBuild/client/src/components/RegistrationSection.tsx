import { useInView } from 'react-intersection-observer';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowRight, CheckCircle, Users, Globe, Sparkles } from 'lucide-react';

export default function RegistrationSection() {
  const { ref, inView } = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  const handleRegisterClick = () => {
    window.open('https://forms.gle/W9T8vXnmDgxdMT3o9', '_blank');
  };

  const benefits = [
    'Join a global network of 100+ SDG Hubs worldwide',
    'Access to exclusive workshops and seminars',
    'Connect with mentors and like-minded changemakers',
    'Participate in impactful community projects',
    'Develop leadership and advocacy skills',
    'Be part of the UN Sustainable Development movement',
  ];

  return (
    <section id="register" className="relative py-20 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10" />
      
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-secondary/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '3s' }} />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8" ref={ref}>
        <div className={`text-center mb-12 transition-all duration-1000 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm text-primary font-medium">Start Your Journey</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
            Join the <span className="text-primary neon-glow">Movement</span>
          </h2>
          
          <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto">
            Be part of the largest generation of youth creating sustainable change. Your voice matters, your actions count.
          </p>
        </div>

        <Card className={`p-8 sm:p-12 backdrop-blur-glass border-accent/30 mb-12 transition-all duration-1000 delay-200 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} data-testid="card-registration">
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h3 className="text-2xl font-bold mb-6">Why Join Us?</h3>
              <ul className="space-y-4">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-muted-foreground">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-6">
              <div className="p-6 rounded-lg bg-primary/5 border border-primary/20">
                <div className="flex items-center gap-3 mb-3">
                  <Users className="w-6 h-6 text-primary" />
                  <h4 className="text-xl font-semibold">Active Community</h4>
                </div>
                <p className="text-muted-foreground">
                  Join 100+ passionate students already making a difference at Strathmore University.
                </p>
              </div>

              <div className="p-6 rounded-lg bg-secondary/5 border border-secondary/20">
                <div className="flex items-center gap-3 mb-3">
                  <Globe className="w-6 h-6 text-secondary" />
                  <h4 className="text-xl font-semibold">Global Network</h4>
                </div>
                <p className="text-muted-foreground">
                  Connect with SDSN Youth Hubs across 100+ universities worldwide.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center pt-8 border-t border-border">
            <p className="text-lg font-medium mb-6">
              Ready to create lasting impact? <span className="text-primary">Register now and start your SDG journey.</span>
            </p>
            
            <Button
              size="lg"
              onClick={handleRegisterClick}
              className="neon-glow-primary hover:scale-105 transition-transform text-lg px-8 py-6"
              data-testid="button-register-main"
            >
              Register Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>

            <p className="text-sm text-muted-foreground mt-4">
              Free to join • No prior experience needed • All students welcome
            </p>
          </div>
        </Card>

        <div className={`text-center transition-all duration-1000 delay-400 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <p className="text-muted-foreground italic">
            "The future we are fighting for is our future as the youth. We need to be at the forefront."
          </p>
          <p className="text-sm text-muted-foreground mt-2">- Samuel Mue, SDG Hub Coordinator</p>
        </div>
      </div>
    </section>
  );
}
